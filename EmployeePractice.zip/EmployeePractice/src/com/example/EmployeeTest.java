/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import com.example.domain.Employee;

/**
 *
 * @author Anubhav
 */
public class EmployeeTest {
    
     
  
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Employee e=new Employee();
         
         e.setEmp_id(101);
         e.setEmp_name("John Smith");
         e.setEmp_ssn("012-34-4567");
         e.setEmp_sal(10000);
         
        int i=e.getEmp_id();
        System.out.println("Employee id is"+i);
        String j;
        j = e.getEmp_name();
        System.out.println("Employee name is"+j);
        double k;
        k = e.getEmp_sal();
        System.out.println("Employe sal is"+k);
        String l=e.getEmp_ssn();
        System.out.println("Employee ssn is"+l);
     }
    
}
