/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.domain;

/**
 *
 * @author Anubhav
 */
public class Employee {

   
        
    private int emp_id;
    private String emp_name;
    private String emp_ssn;
    private double emp_sal;
   // private final int id;
     public Employee(int emp_id,String emp_name,String emp_ssn,double emp_sal) {
         this.emp_id=emp_id;
         this.emp_name=emp_name;
         this.emp_ssn=emp_ssn;
         this.emp_sal=emp_sal;
         
    }
    
    public void raise_sal(double inc)
    {
        emp_sal+=inc;
        
    }
    
    public int getEmp_id() {
        return emp_id;
    }

    public String getEmp_name() {
        return emp_name;
    }
    public String getEmp_ssn() {
        return emp_ssn;
    }

    public double getEmp_sal() {
        return emp_sal;
    }

   

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    }

   

   

   }