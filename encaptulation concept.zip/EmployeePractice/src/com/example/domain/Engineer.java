/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.domain;

/**
 *
 * @author Anubhav
 */
public class Engineer extends Employee{

    public Engineer(int emp_id, String emp_name, String emp_ssn, double emp_sal) {
        super(emp_id, emp_name, emp_ssn, emp_sal);
    }
    
}

