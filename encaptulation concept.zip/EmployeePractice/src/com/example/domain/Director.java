/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.domain;

/**
 *
 * @author Anubhav
 */
public class Director extends Manager{

    private double budget;

    public Director(int emp_id, String emp_name, String emp_ssn, double emp_sal, String dept_name,double budget) {
        super(emp_id, emp_name, emp_ssn, emp_sal, dept_name);
    }

   
    public double getBudget() {
        return budget;
    }
    
    
}

