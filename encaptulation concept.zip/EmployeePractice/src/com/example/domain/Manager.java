/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.domain;

/**
 *
 * @author Anubhav
 */
public class Manager extends Employee{
    
     private String dept_name;

    public Manager(int emp_id, String emp_name, String emp_ssn, double emp_sal,String dept_name) {
        super(emp_id, emp_name, emp_ssn, emp_sal);
        this.dept_name=dept_name;
        
    }

    public String getDept_name() {
        return dept_name;
    }
    
   
}

